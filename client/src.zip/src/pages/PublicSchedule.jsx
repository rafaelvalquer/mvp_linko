import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api } from "../app/api.js";
import Button from "../components/appui/Button.jsx";
import { Input } from "../components/appui/Input.jsx";
import brand from "../assets/brand.png";

function fmtBRL(cents) {
  const v = Number.isFinite(cents) ? cents : 0;
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(v / 100);
}

function toDateInputValue(d = new Date()) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function fmtTime(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

function normStatus(s) {
  return String(s || "")
    .trim()
    .toUpperCase();
}

function safeDate(v) {
  if (!v) return null;
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return null;
  return d;
}

/**
 * ✅ Resolve status do slot de forma robusta:
 * - suporta campos alternativos comuns (status/state/availability/etc)
 * - suporta booleans (available/isAvailable/isFree)
 * - suporta ids que indicam reserva (bookingId/reservationId/holdId)
 */
function resolveSlotStatus(slot) {
  const raw =
    normStatus(slot?.status) ||
    normStatus(slot?.state) ||
    normStatus(slot?.availability) ||
    normStatus(slot?.slotStatus) ||
    normStatus(slot?.bookingStatus) ||
    normStatus(slot?.booking?.status);

  // booleans / flags
  const hasBookingRef =
    !!slot?.bookingId ||
    !!slot?.reservationId ||
    !!slot?.holdId ||
    !!slot?.booking?._id ||
    !!slot?.booking?.id;

  const isAvailableBool =
    slot?.isAvailable ?? slot?.available ?? slot?.isFree ?? slot?.free;

  // Se tem referência de booking/reserva, não é FREE
  if (hasBookingRef) {
    // tenta inferir confirmado/pago
    if (
      ["CONFIRMED", "BOOKED", "PAID", "CONFIRMADO"].includes(raw) ||
      ["CONFIRMED", "PAID"].includes(normStatus(slot?.booking?.paymentStatus))
    ) {
      return "CONFIRMED";
    }
    return "HOLD";
  }

  // Se o slot informa boolean de disponibilidade
  if (isAvailableBool === false) {
    // se não tem raw, assume bloqueado/reservado
    if (!raw) return "HOLD";
    if (["FREE", "AVAILABLE", "OPEN", "LIVRE"].includes(raw)) return "HOLD";
    return raw;
  }

  // Map de sinônimos
  if (["FREE", "AVAILABLE", "OPEN", "LIVRE"].includes(raw)) return "FREE";
  if (
    [
      "HOLD",
      "HELD",
      "RESERVED",
      "RESERVADO",
      "PENDING",
      "WAITING",
      "WAITING_CONFIRMATION",
    ].includes(raw)
  )
    return "HOLD";
  if (["CONFIRMED", "BOOKED", "PAID", "CONFIRMADO", "CONFIRMADA"].includes(raw))
    return "CONFIRMED";
  if (
    ["BLOCKED", "UNAVAILABLE", "BUSY", "INDISPONIVEL", "INDISPONÍVEL"].includes(
      raw,
    )
  )
    return "BLOCKED";

  // fallback
  return raw || "FREE";
}

export default function PublicSchedule() {
  const { token } = useParams();
  const navigate = useNavigate();

  const [offer, setOffer] = useState(null);
  const [offerErr, setOfferErr] = useState("");

  const [date, setDate] = useState(toDateInputValue());
  const [slots, setSlots] = useState([]);
  const [slotsNow, setSlotsNow] = useState(null);
  const [slotsErr, setSlotsErr] = useState("");
  const [loadingSlots, setLoadingSlots] = useState(false);

  const [selected, setSelected] = useState(null);
  const [busy, setBusy] = useState(false);
  const [booking, setBooking] = useState(null);

  function onGoPay() {
    const bookingId = booking?.id || booking?._id || booking?.bookingId;
    if (!bookingId) return;
    navigate(`/p/${token}/pay?bookingId=${encodeURIComponent(bookingId)}`);
  }

  // carrega proposta + respeita flowState
  useEffect(() => {
    setOffer(null);
    setOfferErr("");
    api(`/p/${token}`)
      .then((d) => {
        const step = String(d?.flow?.step || "").toUpperCase();

        // ✅ se abrir /schedule indevidamente, redireciona para o passo correto
        if (step && step !== "SCHEDULE") {
          const bookingId = String(
            d?.flow?.bookingId || d?.booking?.id || "",
          ).trim();
          const q = bookingId
            ? `?bookingId=${encodeURIComponent(bookingId)}`
            : "";

          if (step === "PAYMENT") {
            navigate(`/p/${token}/pay${q}`, { replace: true });
            return;
          }
          if (step === "DONE") {
            navigate(`/p/${token}/done${q}`, { replace: true });
            return;
          }

          // ACCEPT / EXPIRED / CANCELED -> rota base (guard decide)
          navigate(`/p/${token}`, { replace: true });
          return;
        }

        setOffer(d.offer);
      })
      .catch((e) => {
        setOfferErr(e?.message || "Falha ao carregar proposta.");
      });
  }, [token, navigate]);

  const view = useMemo(() => {
    const o = offer || {};
    const inferredType =
      o.offerType ||
      (Array.isArray(o.items) && o.items.length ? "product" : "service");
    const offerType = inferredType === "product" ? "product" : "service";

    const totalCents =
      (Number.isFinite(o.totalCents) && o.totalCents) ||
      (Number.isFinite(o.amountCents) && o.amountCents) ||
      0;

    const depositPctRaw = Number(o.depositPct);
    const depositPct =
      Number.isFinite(depositPctRaw) && depositPctRaw > 0 ? depositPctRaw : 0;

    const depositEnabled = o.depositEnabled === false ? false : depositPct > 0;
    const depositCents = depositEnabled
      ? Math.round((totalCents * depositPct) / 100)
      : 0;
    const remainingCents = Math.max(0, totalCents - depositCents);

    return {
      offerType,
      totalCents,
      depositEnabled,
      depositPct,
      depositCents,
      remainingCents,
    };
  }, [offer]);

  const now = safeDate(slotsNow) || new Date();
  const todayStr = toDateInputValue(new Date());
  const isToday = date === todayStr;
  const pastTolMs = 90_000; // tolerância (90s)

  const getSlotUi = useCallback(
    (s) => {
      const st = resolveSlotStatus(s);
      const start = safeDate(s?.startAt);

      const isPast =
        isToday && start ? start.getTime() <= now.getTime() - pastTolMs : false;

      // ✅ qualquer coisa que não seja FREE = bloqueado (e past também)
      const disabled = st !== "FREE" || isPast;

      const label = isPast
        ? "Horário passado"
        : st === "FREE"
          ? "Livre"
          : st === "HOLD"
            ? "Já reservado"
            : st === "CONFIRMED"
              ? "Já reservado"
              : "Indisponível";

      const tone = isPast
        ? "PAST"
        : st === "FREE"
          ? "FREE"
          : st === "HOLD"
            ? "HOLD"
            : "BLOCKED";

      return { st, isPast, disabled, label, tone };
    },
    [isToday, now, pastTolMs],
  );

  const fetchSlots = useCallback(async () => {
    if (!offer) return;
    setLoadingSlots(true);
    setSlotsErr("");
    try {
      const d = await api(`/p/${token}/slots?date=${encodeURIComponent(date)}`);
      setSlotsNow(d?.now || null);
      setSlots(Array.isArray(d?.slots) ? d.slots : []);
    } catch (e) {
      setSlots([]);
      setSlotsErr(e?.message || "Falha ao carregar horários.");
    } finally {
      setLoadingSlots(false);
    }
  }, [offer, token, date]);

  // carrega slots quando muda a data
  useEffect(() => {
    if (!offer) return;

    setSelected(null);
    setBooking(null);

    fetchSlots();
  }, [token, date, offer, fetchSlots]);

  // ✅ auto refresh: reflete reservas de outros usuários
  useEffect(() => {
    if (!offer) return;
    if (booking) return; // se já reservou, não precisa
    if (loadingSlots) return;

    const id = setInterval(() => {
      fetchSlots();
    }, 12_000);

    return () => clearInterval(id);
  }, [offer, booking, loadingSlots, fetchSlots]);

  // impede seleção fantasma: slot deixou de ser FREE ou virou passado
  useEffect(() => {
    if (!selected) return;
    const cur = slots.find(
      (s) => s?.startAt === selected?.startAt && s?.endAt === selected?.endAt,
    );
    if (!cur) {
      setSelected(null);
      return;
    }
    if (getSlotUi(cur).disabled) setSelected(null);
  }, [slots, slotsNow, date, selected, getSlotUi]);

  async function confirmBooking() {
    if (!selected) return;
    const selUi = getSlotUi(selected);
    if (selUi.disabled) return;

    setBusy(true);
    setSlotsErr("");
    try {
      const res = await api(`/p/${token}/book`, {
        method: "POST",
        body: JSON.stringify({
          startAt: selected.startAt,
          endAt: selected.endAt,
          customerName: offer?.customerName || "",
          customerWhatsApp: offer?.customerWhatsApp || "",
        }),
      });
      if (!res?.ok) throw new Error(res?.error || "Falha ao criar reserva.");
      setBooking(res.booking);

      // reflete HOLD imediatamente
      try {
        const d = await api(
          `/p/${token}/slots?date=${encodeURIComponent(date)}`,
        );
        setSlotsNow(d?.now || null);
        setSlots(Array.isArray(d.slots) ? d.slots : []);
      } catch {}
    } catch (e) {
      setBooking(null);

      const msg = e?.message || "Falha ao criar reserva.";

      // quando o backend retornar 409 "Horário indisponível."
      if (/indisponível/i.test(msg)) {
        setSlotsErr("Horário acabou de ser reservado. Escolha outro.");
        setSelected(null);
        try {
          const d = await api(
            `/p/${token}/slots?date=${encodeURIComponent(date)}`,
          );
          setSlotsNow(d?.now || null);
          setSlots(Array.isArray(d.slots) ? d.slots : []);
        } catch {}
      } else {
        setSlotsErr(msg);
      }
    } finally {
      setBusy(false);
    }
  }

  if (offerErr) {
    return (
      <div className="min-h-screen bg-zinc-50 p-6">
        <div className="mx-auto max-w-2xl rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
          {offerErr}
        </div>
      </div>
    );
  }

  if (!offer) {
    return (
      <div className="min-h-screen bg-zinc-50 p-6">
        <div className="mx-auto max-w-2xl rounded-2xl border bg-white p-4 text-sm text-zinc-600">
          Carregando…
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-50">
      <div className="border-b bg-white">
        <div className="mx-auto flex max-w-2xl items-center justify-between px-4 py-3">
          <div>
            <img
              src={brand}
              alt="Luminor Pay"
              className="h-9 w-9 rounded-xl object-contain ring-1 ring-zinc-200 bg-white p-1"
            />
            <div className="text-sm font-semibold text-zinc-900">
              LuminorPay
            </div>
            <div className="text-xs text-zinc-500">
              Agendamento • Link público
            </div>
          </div>
          <Button
            type="button"
            variant="secondary"
            onClick={() => navigate(`/p/${token}`)}
          >
            Voltar
          </Button>
        </div>
      </div>

      <div className="mx-auto grid max-w-2xl gap-4 px-4 py-6">
        {String(offer?.status || "").toUpperCase() === "ACCEPTED" ? (
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900">
            <div className="font-semibold">Proposta aceita!</div>
            <div className="mt-1 text-emerald-900/90">
              Agora escolha a data e horário para continuar.
            </div>
          </div>
        ) : null}

        {/* Resumo */}
        <div className="rounded-2xl border bg-white p-6 shadow-sm">
          <div className="text-xs font-semibold text-zinc-500">Resumo</div>
          <div className="mt-1 text-xl font-semibold text-zinc-900">
            {offer.title}
          </div>
          <div className="mt-1 text-sm text-zinc-600">
            Para:{" "}
            <span className="font-semibold text-zinc-900">
              {offer.customerName}
            </span>
          </div>

          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border bg-zinc-50 p-4">
              <div className="text-xs font-semibold text-zinc-500">Total</div>
              <div className="mt-1 text-lg font-semibold text-zinc-900">
                {fmtBRL(view.totalCents)}
              </div>
              {view.depositEnabled ? (
                <div className="mt-1 text-xs text-zinc-600">
                  Sinal:{" "}
                  <span className="font-semibold">
                    {fmtBRL(view.depositCents)}
                  </span>{" "}
                  ({view.depositPct}%) • Restante:{" "}
                  <span className="font-semibold">
                    {fmtBRL(view.remainingCents)}
                  </span>
                </div>
              ) : (
                <div className="mt-1 text-xs text-zinc-600">
                  Pagamento integral
                </div>
              )}
            </div>

            <div className="rounded-2xl border bg-zinc-50 p-4">
              <div className="text-xs font-semibold text-zinc-500">Duração</div>
              <div className="mt-1 text-lg font-semibold text-zinc-900">
                {offer.durationMin || 0} min
              </div>
              <div className="mt-1 text-xs text-zinc-600">
                Escolha um horário disponível para reservar.
              </div>
            </div>
          </div>
        </div>

        {/* Seleção de data */}
        <div className="rounded-2xl border bg-white p-6 shadow-sm">
          <div className="text-sm font-semibold text-zinc-900">
            Selecione a data
          </div>
          <div className="mt-2 max-w-xs">
            <Input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>
        </div>

        {/* Slots */}
        <div className="rounded-2xl border bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="text-sm font-semibold text-zinc-900">
              Horários disponíveis
            </div>
            {loadingSlots ? (
              <div className="text-xs text-zinc-500">Carregando…</div>
            ) : null}
          </div>

          {slotsErr ? (
            <div className="mt-3 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800">
              {slotsErr}
            </div>
          ) : null}

          {isToday ? (
            <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
              Horários passados ficam indisponíveis automaticamente.
            </div>
          ) : null}

          {loadingSlots ? (
            <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-10 rounded-xl bg-zinc-100" />
              ))}
            </div>
          ) : slots.length === 0 ? (
            <div className="mt-3 text-sm text-zinc-600">
              Sem horários disponíveis.
            </div>
          ) : (
            <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {slots.map((s) => {
                const ui = getSlotUi(s);
                const disabled = ui.disabled;
                const isSel = selected?.startAt === s.startAt;

                const baseCls =
                  "rounded-xl border px-3 py-2 text-sm font-semibold transition text-left";

                const cls =
                  ui.tone === "FREE"
                    ? "bg-white text-zinc-900 hover:bg-zinc-50 border-zinc-200"
                    : ui.tone === "PAST"
                      ? "cursor-not-allowed bg-zinc-50 text-zinc-400 border-zinc-200"
                      : "cursor-not-allowed bg-amber-50 text-amber-900 border-amber-200";

                const selCls = isSel
                  ? "border-emerald-500 ring-2 ring-emerald-100"
                  : "";

                return (
                  <button
                    key={s.startAt}
                    type="button"
                    disabled={disabled || busy || !!booking}
                    onClick={() => {
                      if (disabled || busy || booking) return;
                      setSelected(s);
                    }}
                    className={[baseCls, cls, selCls].filter(Boolean).join(" ")}
                    aria-pressed={isSel}
                    title={disabled && ui.label ? ui.label : ""}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span>{fmtTime(s.startAt)}</span>
                      {ui.tone !== "FREE" ? (
                        <span className="text-[10px] font-bold rounded-full px-2 py-0.5 border border-amber-200 bg-white/60">
                          BLOQUEADO
                        </span>
                      ) : null}
                    </div>
                    <div className="text-xs font-medium opacity-80">
                      {ui.label}
                    </div>
                  </button>
                );
              })}
            </div>
          )}

          <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div className="text-xs text-zinc-600">
              {selected ? (
                <>
                  Selecionado:{" "}
                  <span className="font-semibold">
                    {fmtTime(selected.startAt)}
                  </span>
                </>
              ) : (
                "Selecione um horário para reservar."
              )}
            </div>

            {booking ? (
              <Button type="button" onClick={onGoPay}>
                Ir para pagamento
              </Button>
            ) : (
              <Button
                type="button"
                onClick={confirmBooking}
                disabled={!selected || busy}
              >
                {busy ? "Reservando…" : "Reservar horário"}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
